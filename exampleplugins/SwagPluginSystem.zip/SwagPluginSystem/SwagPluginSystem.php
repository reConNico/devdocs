<?php

namespace SwagPluginSystem;

use Shopware\Components\Plugin;

class SwagPluginSystem extends Plugin
{
    
}