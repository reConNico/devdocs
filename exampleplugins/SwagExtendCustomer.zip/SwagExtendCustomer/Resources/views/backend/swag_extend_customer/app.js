//{block name="backend/customer/application"}
// {$smarty.block.parent}
// {include file="backend/swag_extend_customer/controller/my_own_controller.js"}
// {include file="backend/swag_extend_customer/view/detail/my_own_tab.js"}
//{/block}
